﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace Sokoban
{
    class GridPopulate : Window
    {
        private AppWindow window { get; set; }

        //construct
        public GridPopulate(AppWindow window)
        {
            this.window = window;
        }//end method

        //basic grid populated
        public void basicGrid()
        {
            int x, y;
            for (x = 0; x <= 9; x++)
            {
                for (y = 0; y <= 9; y++)
                {
                    drawImages("Image\\blank.bmp", x, y);
                }//end for
            }//end for
            locations();

            Level1();
        }//end method

        private void locations()
        {
            //keep updating the location of character
            window.warehouseKeeperRow = 4;
            window.warehouseKeeperColumn = 4;

            //keep updating the location of crate
            window.crateRow = 3;
            window.crateColumn = 3;

            //location of goal
            window.goalRow = 7;
            window.goalColumn = 2;
        }

        public void drawImages(string location, int row, int column)
        {
            Image myImages = new Image() { Source = new BitmapImage(new Uri(location, UriKind.Relative)) };
            window.gameGrid.Children.Add(myImages);

            try
            {
                Grid.SetRow(myImages, row);
                Grid.SetColumn(myImages, column);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot Go Pass This Point");
            }
        }//end method

        //level design
        private void Level1()
        {
            //warehousekeeper starting point
            drawImages("Image\\warehouseKeeper.bmp", 4, 4);

            //crate location
            drawImages("Image\\Crate.bmp", 3, 3);

            //goal location
            drawImages("Image\\goal.bmp", 8, 8);

            //walls location
            drawImages("Image\\wall.bmp", 2, 2);
        }//end method
    }//end class
}//end namespace