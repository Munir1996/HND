﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows;

namespace Sokoban
{
    class Movement
    {
        private AppWindow window { get; set; }
        private GridPopulate popGrid { get; set; }
        Tile[,] map = new Tile[10, 10];
        private int targetCellRow, targetCellColumn;
        private int crateTargetCellRow, crateTargetCellColumn;

        //construct
        public Movement(AppWindow window)
        {
            this.window = window;

            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 1; y++)
                {
                    map[x, 0] = new WallTile();
                    map[0, x] = new WallTile();
                }
            }

            popGrid = new GridPopulate(window);
            for (int x = 0; x <10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    map[x, y] = new FloorTile();
                }
            }

            map[8, 8] = new FinishTile(); //finish location
            map[2, 2] = new WallTile(); //wall loaction
            map[3, 3] = new CrateTile(); //crate loaction
        }

        //move character
        public void moveCharacter(KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left: move("left"); break; //call appropriate movement method
                case Key.Up: move("up"); break;
                case Key.Right: move("right"); break;
                case Key.Down: move("down"); break;
                default: break;
            }
        }

        private void move(string direction)
        {
            int i=0, j = 0;

            switch (direction)
            {
                case "left": i = 0; j = -1; break;
                case "up": i = -1; j = 0; break;
                case "right": i = 0; j = 1; break;
                case "down": i = 1; j = 0; break;
                default: break;
            }

            try
            {

                if (((targetCellRow = window.warehouseKeeperRow + i) < 10) && ((targetCellColumn = window.warehouseKeeperColumn + j) < 10) && map[window.warehouseKeeperRow + i, window.warehouseKeeperColumn + j] is FloorTile)
                {

                    targetCellRow = window.warehouseKeeperRow + i;
                    targetCellColumn = window.warehouseKeeperColumn + j;

                    popGrid = new GridPopulate(window);
                    // draw a penguin in the new co-ordinates
                    popGrid.drawImages("Image\\warehouseKeeper.bmp", targetCellRow, targetCellColumn);
                    // update the original cell where the penguin was to be a blank cell
                    popGrid.drawImages("Image\\blank.bmp", window.warehouseKeeperRow, window.warehouseKeeperColumn);
                    // update the location of the penguin to these new co-ordinates
                    updateWarehouseKeeperLocation();

                }
                else if (((targetCellRow = window.warehouseKeeperRow + i) < 10) && ((targetCellColumn = window.warehouseKeeperColumn + j) < 10) && map[window.warehouseKeeperRow + i, window.warehouseKeeperColumn + j] is CrateTile)
                {
                    targetCellRow = window.warehouseKeeperRow + i;
                    targetCellColumn = window.warehouseKeeperColumn + j;
                    crateTargetCellColumn = targetCellColumn - 1;
                    crateTargetCellRow = targetCellRow;

                    popGrid = new GridPopulate(window);
                    // draw a penguin in the new co-ordinates
                    popGrid.drawImages("Image\\warehousKeeper.bmp", targetCellRow, targetCellColumn);
                    // update the original cell where the penguin was to be a blank cell
                    popGrid.drawImages("Image\\blank.bmp", window.warehouseKeeperRow, window.warehouseKeeperColumn);
                    // update the location of the penguin to these new co-ordinates
                    popGrid.drawImages("Image\\Crate.bmp", crateTargetCellRow, crateTargetCellColumn);


                    updateWarehouseKeeperLocation();
                    updateCrateLocation();

                }
            }
            catch (Exception ex)
            {

            }
        }//end method
        
        private void updateWarehouseKeeperLocation()
        {
            window.warehouseKeeperRow = targetCellRow;
            window.warehouseKeeperColumn = targetCellColumn;
        }//end method
        
        private void updateCrateLocation()
        {
            window.crateRow = crateTargetCellRow;
            window.crateColumn = crateTargetCellColumn;
        }//end method
    }//end class 
}//end namespace