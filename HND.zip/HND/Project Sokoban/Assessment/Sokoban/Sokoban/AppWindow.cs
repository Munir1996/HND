﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Sokoban
{
    class AppWindow : Window
    {
        //creates new canvas area
        private Canvas windowCanvas { get; set; }

        //create return button to get back to the main window
        private Button returnButton { get; set; }

        //resest level
        private Button restartButton { get; set; }

        //create a grid
        public Grid gameGrid { get; set; }

        //create a border around the grid
        private Border gridBorder { get; set; }

        //populate grid
        private GridPopulate populateGrid { get; set; }

        //character
        public int warehouseKeeperRow { get; set; }
        public int warehouseKeeperColumn { get; set; }
        public int crateRow { get; set; }
        public int crateColumn { get; set; }
        public int goalRow { get; set; }
        public int goalColumn { get; set; }
        private Movement mover { get; set; }

        private GridPopulate level { get; set; }

        //construct
        public AppWindow (string windowName)
        {
            this.Title = windowName;
            startWindows();
        }//end method

        //start game window
        private void startWindows()
        {
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            windowCanvas = new Canvas();
            newGrid();
            area();
            gameGrid.Focus();

            populateGrid = new GridPopulate(this);
            populateGrid.basicGrid();

            this.Content = this.windowCanvas;
            mover = new Movement(this);

            level = new GridPopulate(this);

            mainPageEvents();
        }//end method

        //create a grid
        private void newGrid()
        {
            //create a border around the grid
            gridBorder = new Border();
            //how thick the border is
            gridBorder.BorderThickness = new Thickness(15.00);
            //the colour of the border
            gridBorder.BorderBrush = Brushes.Red;
            
            //grid is 600 x 600 and is in the top left of the screan
            gameGrid = new Grid();
            gameGrid.Width = gameGrid.Height = 600;
            gameGrid.HorizontalAlignment = HorizontalAlignment.Left;
            gameGrid.VerticalAlignment = VerticalAlignment.Top;
            gameGrid.Focusable = true;
            gridBorder.Child = gameGrid;

            //there are 10 squres in column and row
            for (int i = 0; i <= 9; i++)
                gameGrid.ColumnDefinitions.Add(new ColumnDefinition());
            for (int i = 0; i <= 9; i++)
                gameGrid.RowDefinitions.Add(new RowDefinition());
        }//end method

        //make button and an area
        private void area()
        {
            //the look of button
            returnButton = new Button();
            returnButton.Height = 30;
            returnButton.Width = 250;
            returnButton.FontSize = 20;
            returnButton.Focusable = false;
            returnButton.Content = "Back to Main Window";

            //the look of button
            restartButton = new Button();
            restartButton.Height = 30;
            restartButton.Width = 250;
            restartButton.FontSize = 20;
            restartButton.Focusable = false;
            restartButton.Content = "Reset";

            //this shows the button on the screen
            windowCanvas.Children.Add(returnButton);
            //this shows the grid on screen
            windowCanvas.Children.Add(gridBorder);
            //this shows the button on the screen;
            windowCanvas.Children.Add(restartButton);

            //this places the button where on the screen
            Canvas.SetRight(returnButton, 25);
            Canvas.SetTop(returnButton, 100);

            //this places the button where on the screen
            Canvas.SetTop(restartButton, 150);
            Canvas.SetRight(restartButton, 25);
        }//end method

        private void mainPageEvents()
        {
            returnButton.Click += returnButton_Click; // event for return to start page
            restartButton.Click += resetButton_Click; //event reset level
            gameGrid.KeyDown += gameGrid_KeyDown; //event for a key pressed
        }

        //reset level
        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
                level.basicGrid();
                MessageBox.Show("Level has been reseted");
        }

        //call for move in the movement class
        protected void gameGrid_KeyDown(object sender, KeyEventArgs e)
        {
            mover.moveCharacter(e);
        }

        //return to main menu
        protected void returnButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MainWindow = new MainWindow();
            MainWindow.Show();
            this.Close();
        }
    }//end class
}//end namespace