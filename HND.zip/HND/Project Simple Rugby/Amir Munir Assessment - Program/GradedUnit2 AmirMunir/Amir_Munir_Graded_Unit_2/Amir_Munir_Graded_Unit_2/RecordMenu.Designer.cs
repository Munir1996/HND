﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class RecordMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.btnPlayerProfile = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(12, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(94, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Select One Option";
            // 
            // btnPlayerProfile
            // 
            this.btnPlayerProfile.Location = new System.Drawing.Point(6, 35);
            this.btnPlayerProfile.Name = "btnPlayerProfile";
            this.btnPlayerProfile.Size = new System.Drawing.Size(100, 23);
            this.btnPlayerProfile.TabIndex = 1;
            this.btnPlayerProfile.Text = "Player Profile";
            this.btnPlayerProfile.UseVisualStyleBackColor = true;
            this.btnPlayerProfile.Click += new System.EventHandler(this.btnPlayerProfile_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(6, 64);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 23);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Go Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // RecordMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(203, 136);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnPlayerProfile);
            this.Controls.Add(this.Title);
            this.Name = "RecordMenu";
            this.Text = "RecordMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button btnPlayerProfile;
        private System.Windows.Forms.Button btnBack;
    }
}