﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class Membership : Form
    {
        public Membership()
        {
            InitializeComponent();
            txtTele.MaxLength = 11;
            txtSRU.MaxLength = 4;
        }

        //gather information provided by the user
        private void getDetails()
        {
            try
            {
                Details.Name = txtName.Text;
                Details.Dob = dtpDateOfBirth.Text;
                Details.Email = txtEmail.Text;
                Details.Sru = txtSRU.Text;
                Details.TeleNo = txtTele.Text;
            }//end try
            catch (Exception ex)
            {
                MessageBox.Show("All Fileds must be Complete");
            }//end catch

            //check for name
            if (Details.Name.Length <= 0)
            {
                MessageBox.Show("Must Enter Name");
            }

            //check for dob
            if (Details.Dob.Length <= 0)
            {
                MessageBox.Show("Must Choose a Date of Birth");
            }

            //check for e-mail
            if (Details.Email.Length <= 0)
            {
                MessageBox.Show("Must Enter E-Mail");
            }
            else if (Details.Email.Contains("@") == false)
            {
                MessageBox.Show("Player's E-mail Must Have @");
            }

            //check sru number
            if (txtSRU.Text.Length <= 3)
            {
                MessageBox.Show("Muster Enter a Four digit SRU Number");
            }

            //check telephone number
            if (txtTele.Text.Length <= 10)
            {
                MessageBox.Show("Must Enter 11 digit for the Telephone Number ");
            }
        }//end method

        private void btnComplete_Click(object sender, EventArgs e)
        {
            //stores user details
            getDetails();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            //navigates to show membership form
            ShowMembershipForm result = new ShowMembershipForm();
            result.Show();
            this.Hide();
        }

        //enter only letters
        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        //enter only numbers
        private void txtSRU_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {

                e.Handled = true;
            }
        }

        //enters only numbers
        private void txtTele_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {

                e.Handled = true;
            }
        }//end
    }//end class
}//end namespace