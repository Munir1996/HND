﻿
namespace Amir_Munir_Graded_Unit_2
{
    class Details
    {
        //junior details
        private static string name;
        private static string email;
        private static string dob;
        private static string sru;
        private static string teleNo;

        //player profile details
        private static string squadNo;
        private static string passComments;
        private static string tackComments;
        private static string kickComments;

        //Guardian details
        private static string gName;
        private static string gEmail;
        private static string gTeleNo;

        //dropboxes details
        private static string standeredLst;
        private static string spinLst;
        private static string popLst;
        private static string frontLst;
        private static string rearLst;
        private static string sideLst;
        private static string scrabbleLst;
        private static string dropLst;
        private static string puntLst;
        private static string grubberLst;
        private static string goalLst;

        //properties

        //junior details
        public static string Name 
        { 
            get
            {
                return name;
            }
            set 
            {
                name = value;
            }
        }

        public static string Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }

        public static string Dob 
        {
            get
            {
                return dob;
            }
            set
            {
                dob = value;
            }
        }

        public static string Sru
        {
            get
            {
                return sru;
            }
            set
            {
                sru = value;
            }
        }

        public static string TeleNo
        {
            get
            {
                return teleNo;
            }
            set
            {
                teleNo = value;
            }
        }

        //player profile details
        public static string SquadNo
        {
            get
            {
                return squadNo;
            }
            set
            {
                squadNo = value;
            }
        }

        public static string Passcomments
        {
            get
            {
                return passComments;
            }
            set
            {
                passComments = value;
            }
        }

        public static string Tackcomments
        {
            get
            {
                return tackComments;
            }
            set
            {
                tackComments = value;
            }
        }

        public static string Kickcomments
        {
            get
            {
                return kickComments;
            }
            set
            {
                kickComments = value;
            }
        }
        
        //Guardian details
        public static string Gname
        {
            get
            {
                return gName;
            }
            set
            {
                gName = value;
            }
        }

        public static string Gemail
        {
            get
            {
                return gEmail;
            }
            set
            {
                gEmail = value;
            }
        }

        public static string GTeleNo 
        {
            get
            {
                return gTeleNo;
            }
            set
            {
                gTeleNo = value;
            }
        }

        //dropboxes details
        public static string StanderedLst
        {
            get
            {
                return standeredLst;
            }
            set
            {
                standeredLst = value;
            }
        }

        public static string SpinLst
        {
            get
            {
                return spinLst;
            }
            set
            {
                spinLst = value;
            }
        }

        public static string PopLst
        {
            get
            {
                return popLst;
            }
            set
            {
                popLst = value;
            }
        }

        public static string FrontLst
        {
            get
            {
                return frontLst;
            }
            set
            {
                frontLst = value;
            }
        }

        public static string RearLst
        {
            get
            {
                return rearLst;
            }
            set
            {
                rearLst = value;
            }
        }

        public static string SideLst
        {
            get
            {
                return sideLst;
            }
            set
            {
                sideLst = value;
            }
        }

        public static string ScrabbleLst
        {
            get
            {
                return scrabbleLst;
            }
            set
            {
                scrabbleLst = value;
            }
        }

        public static string DropLst
        {
            get
            {
                return dropLst;
            }
            set
            {
                dropLst = value;
            }
        }

        public static string PuntLst
        {
            get
            {
                return puntLst;
            }
            set
            {
                puntLst = value;
            }
        }

        public static string GrubberLst
        {
            get
            {
                return grubberLst;
            }
            set
            {
                grubberLst = value;
            }
        }

        public static string GoalLst
        {
            get
            {
                return goalLst;
            }
            set
            {
                goalLst = value;
            }
        }
    }//end class
}//end namespace