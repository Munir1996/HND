﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //naviagates to the registration Menu
        private void btnRegistrationMenu_Click(object sender, EventArgs e)
        {
            RegMenu reg = new RegMenu();
            reg.Show();
            this.Hide();
        }//end method

        //navigate to record menu
        private void btnRecordMenu_Click(object sender, EventArgs e)
        {
            RecordMenu record = new RecordMenu();
            record.Show();
            this.Hide();
        }//end of method

        //exit program
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }//end method
    }//end class
}//end namespace
