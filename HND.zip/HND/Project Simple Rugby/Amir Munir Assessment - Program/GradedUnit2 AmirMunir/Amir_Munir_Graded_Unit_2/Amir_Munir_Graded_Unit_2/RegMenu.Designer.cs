﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class RegMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.btnMembership = new System.Windows.Forms.Button();
            this.btnJuniorMembership = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(18, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(94, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Select One Option";
            // 
            // btnMembership
            // 
            this.btnMembership.Location = new System.Drawing.Point(12, 47);
            this.btnMembership.Name = "btnMembership";
            this.btnMembership.Size = new System.Drawing.Size(111, 23);
            this.btnMembership.TabIndex = 1;
            this.btnMembership.Text = "Membership";
            this.btnMembership.UseVisualStyleBackColor = true;
            this.btnMembership.Click += new System.EventHandler(this.btnMembership_Click);
            // 
            // btnJuniorMembership
            // 
            this.btnJuniorMembership.Location = new System.Drawing.Point(12, 76);
            this.btnJuniorMembership.Name = "btnJuniorMembership";
            this.btnJuniorMembership.Size = new System.Drawing.Size(111, 23);
            this.btnJuniorMembership.TabIndex = 2;
            this.btnJuniorMembership.Text = "Junior Membership";
            this.btnJuniorMembership.UseVisualStyleBackColor = true;
            this.btnJuniorMembership.Click += new System.EventHandler(this.btnJuniorMembership_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(12, 105);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(111, 23);
            this.btnBack.TabIndex = 3;
            this.btnBack.Text = "Go Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // RegMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(192, 178);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnJuniorMembership);
            this.Controls.Add(this.btnMembership);
            this.Controls.Add(this.Title);
            this.Name = "RegMenu";
            this.Text = "RegMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button btnMembership;
        private System.Windows.Forms.Button btnJuniorMembership;
        private System.Windows.Forms.Button btnBack;
    }
}