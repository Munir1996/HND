﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class JuniorMembership
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnComplete = new System.Windows.Forms.Button();
            this.txtGTeleNum = new System.Windows.Forms.TextBox();
            this.txtGEmail = new System.Windows.Forms.TextBox();
            this.txtTele = new System.Windows.Forms.TextBox();
            this.txtGName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtSRU = new System.Windows.Forms.TextBox();
            this.btnResult = new System.Windows.Forms.Button();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(127, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(81, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Complete Fields";
            // 
            // label1
            // 
            this.label1.AccessibleName = "";
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter Name";
            // 
            // label2
            // 
            this.label2.AccessibleName = "";
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Choose Date of Birth";
            // 
            // label3
            // 
            this.label3.AccessibleName = "";
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Enter SRU Number";
            // 
            // label4
            // 
            this.label4.AccessibleName = "";
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enter E-Mail";
            // 
            // label5
            // 
            this.label5.AccessibleName = "";
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Enter Guardian Telephone Number";
            // 
            // label6
            // 
            this.label6.AccessibleName = "";
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Enter Guardian E-Mail";
            // 
            // label7
            // 
            this.label7.AccessibleName = "";
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Enter Guardian Name";
            // 
            // label8
            // 
            this.label8.AccessibleName = "";
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Enter Telephone Number";
            // 
            // btnComplete
            // 
            this.btnComplete.Location = new System.Drawing.Point(265, 295);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(75, 23);
            this.btnComplete.TabIndex = 9;
            this.btnComplete.Text = "Complete";
            this.btnComplete.UseVisualStyleBackColor = true;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // txtGTeleNum
            // 
            this.txtGTeleNum.Location = new System.Drawing.Point(243, 258);
            this.txtGTeleNum.Name = "txtGTeleNum";
            this.txtGTeleNum.Size = new System.Drawing.Size(100, 20);
            this.txtGTeleNum.TabIndex = 10;
            this.txtGTeleNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGTeleNum_KeyPress);
            // 
            // txtGEmail
            // 
            this.txtGEmail.Location = new System.Drawing.Point(160, 229);
            this.txtGEmail.Name = "txtGEmail";
            this.txtGEmail.Size = new System.Drawing.Size(183, 20);
            this.txtGEmail.TabIndex = 11;
            // 
            // txtTele
            // 
            this.txtTele.Location = new System.Drawing.Point(243, 171);
            this.txtTele.Name = "txtTele";
            this.txtTele.Size = new System.Drawing.Size(100, 20);
            this.txtTele.TabIndex = 13;
            this.txtTele.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTele_KeyPress);
            // 
            // txtGName
            // 
            this.txtGName.Location = new System.Drawing.Point(160, 200);
            this.txtGName.Name = "txtGName";
            this.txtGName.Size = new System.Drawing.Size(183, 20);
            this.txtGName.TabIndex = 12;
            this.txtGName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGName_KeyPress);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(160, 51);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(183, 20);
            this.txtName.TabIndex = 17;
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(160, 109);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(183, 20);
            this.txtEmail.TabIndex = 15;
            // 
            // txtSRU
            // 
            this.txtSRU.Location = new System.Drawing.Point(243, 138);
            this.txtSRU.Name = "txtSRU";
            this.txtSRU.Size = new System.Drawing.Size(100, 20);
            this.txtSRU.TabIndex = 14;
            this.txtSRU.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSRU_KeyPress);
            // 
            // btnResult
            // 
            this.btnResult.Location = new System.Drawing.Point(184, 295);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(75, 23);
            this.btnResult.TabIndex = 18;
            this.btnResult.Text = "Show Result";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.CustomFormat = "dd-MM-yyyy";
            this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateOfBirth.Location = new System.Drawing.Point(243, 77);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(100, 20);
            this.dtpDateOfBirth.TabIndex = 19;
            this.dtpDateOfBirth.Value = new System.DateTime(2017, 5, 15, 14, 35, 12, 0);
            // 
            // JuniorMembership
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 330);
            this.Controls.Add(this.dtpDateOfBirth);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtSRU);
            this.Controls.Add(this.txtTele);
            this.Controls.Add(this.txtGName);
            this.Controls.Add(this.txtGEmail);
            this.Controls.Add(this.txtGTeleNum);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Title);
            this.Name = "JuniorMembership";
            this.Text = "Junior";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.TextBox txtGTeleNum;
        private System.Windows.Forms.TextBox txtGEmail;
        private System.Windows.Forms.TextBox txtTele;
        private System.Windows.Forms.TextBox txtGName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtSRU;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
    }
}