﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class PlayerProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lstStandard = new System.Windows.Forms.CheckedListBox();
            this.lstSpin = new System.Windows.Forms.CheckedListBox();
            this.lstPop = new System.Windows.Forms.CheckedListBox();
            this.lstSide = new System.Windows.Forms.CheckedListBox();
            this.lstRear = new System.Windows.Forms.CheckedListBox();
            this.lstFront = new System.Windows.Forms.CheckedListBox();
            this.lstScrabble = new System.Windows.Forms.CheckedListBox();
            this.lstGoal = new System.Windows.Forms.CheckedListBox();
            this.lstGrubber = new System.Windows.Forms.CheckedListBox();
            this.lstPunt = new System.Windows.Forms.CheckedListBox();
            this.lstDrop = new System.Windows.Forms.CheckedListBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtSquadNo = new System.Windows.Forms.TextBox();
            this.btnComplete = new System.Windows.Forms.Button();
            this.rtxtPass = new System.Windows.Forms.RichTextBox();
            this.rtxtTack = new System.Windows.Forms.RichTextBox();
            this.rtxtKick = new System.Windows.Forms.RichTextBox();
            this.btnResult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(176, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(95, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Complete All Fields";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Squad No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Passing";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Category";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 65);
            this.label5.TabIndex = 8;
            this.label5.Text = "Standard\r\n\r\nSpin\r\n\r\nPop";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(104, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Skills";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 368);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kicking";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Tackling";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(324, 134);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Comments (Optional)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(216, 134);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Skill Level";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(104, 368);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 91);
            this.label12.TabIndex = 10;
            this.label12.Text = "Drop\r\n\r\nPunt\r\n\r\nGrubber\r\n\r\nGoal";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(104, 249);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 91);
            this.label13.TabIndex = 9;
            this.label13.Text = "Front\r\n\r\nRear\r\n\r\nSide\r\n\r\nScrabble";
            // 
            // lstStandard
            // 
            this.lstStandard.FormattingEnabled = true;
            this.lstStandard.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstStandard.Location = new System.Drawing.Point(219, 161);
            this.lstStandard.Name = "lstStandard";
            this.lstStandard.Size = new System.Drawing.Size(52, 19);
            this.lstStandard.TabIndex = 13;
            // 
            // lstSpin
            // 
            this.lstSpin.FormattingEnabled = true;
            this.lstSpin.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstSpin.Location = new System.Drawing.Point(219, 186);
            this.lstSpin.Name = "lstSpin";
            this.lstSpin.Size = new System.Drawing.Size(52, 19);
            this.lstSpin.TabIndex = 14;
            // 
            // lstPop
            // 
            this.lstPop.FormattingEnabled = true;
            this.lstPop.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstPop.Location = new System.Drawing.Point(219, 211);
            this.lstPop.Name = "lstPop";
            this.lstPop.Size = new System.Drawing.Size(52, 19);
            this.lstPop.TabIndex = 15;
            // 
            // lstSide
            // 
            this.lstSide.FormattingEnabled = true;
            this.lstSide.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstSide.Location = new System.Drawing.Point(219, 299);
            this.lstSide.Name = "lstSide";
            this.lstSide.Size = new System.Drawing.Size(52, 19);
            this.lstSide.TabIndex = 18;
            // 
            // lstRear
            // 
            this.lstRear.FormattingEnabled = true;
            this.lstRear.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstRear.Location = new System.Drawing.Point(219, 274);
            this.lstRear.Name = "lstRear";
            this.lstRear.Size = new System.Drawing.Size(52, 19);
            this.lstRear.TabIndex = 17;
            // 
            // lstFront
            // 
            this.lstFront.FormattingEnabled = true;
            this.lstFront.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstFront.Location = new System.Drawing.Point(219, 249);
            this.lstFront.Name = "lstFront";
            this.lstFront.Size = new System.Drawing.Size(52, 19);
            this.lstFront.TabIndex = 16;
            // 
            // lstScrabble
            // 
            this.lstScrabble.FormattingEnabled = true;
            this.lstScrabble.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstScrabble.Location = new System.Drawing.Point(219, 324);
            this.lstScrabble.Name = "lstScrabble";
            this.lstScrabble.Size = new System.Drawing.Size(52, 19);
            this.lstScrabble.TabIndex = 19;
            // 
            // lstGoal
            // 
            this.lstGoal.FormattingEnabled = true;
            this.lstGoal.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstGoal.Location = new System.Drawing.Point(219, 443);
            this.lstGoal.Name = "lstGoal";
            this.lstGoal.Size = new System.Drawing.Size(52, 19);
            this.lstGoal.TabIndex = 23;
            // 
            // lstGrubber
            // 
            this.lstGrubber.FormattingEnabled = true;
            this.lstGrubber.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstGrubber.Location = new System.Drawing.Point(219, 418);
            this.lstGrubber.Name = "lstGrubber";
            this.lstGrubber.Size = new System.Drawing.Size(52, 19);
            this.lstGrubber.TabIndex = 22;
            // 
            // lstPunt
            // 
            this.lstPunt.FormattingEnabled = true;
            this.lstPunt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstPunt.Location = new System.Drawing.Point(219, 393);
            this.lstPunt.Name = "lstPunt";
            this.lstPunt.Size = new System.Drawing.Size(52, 19);
            this.lstPunt.TabIndex = 21;
            // 
            // lstDrop
            // 
            this.lstDrop.FormattingEnabled = true;
            this.lstDrop.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstDrop.Location = new System.Drawing.Point(219, 368);
            this.lstDrop.Name = "lstDrop";
            this.lstDrop.Size = new System.Drawing.Size(52, 19);
            this.lstDrop.TabIndex = 20;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(107, 46);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 27;
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            // 
            // txtSquadNo
            // 
            this.txtSquadNo.Location = new System.Drawing.Point(107, 78);
            this.txtSquadNo.Name = "txtSquadNo";
            this.txtSquadNo.Size = new System.Drawing.Size(100, 20);
            this.txtSquadNo.TabIndex = 28;
            this.txtSquadNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSquadNo_KeyPress);
            // 
            // btnComplete
            // 
            this.btnComplete.Location = new System.Drawing.Point(353, 492);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(75, 23);
            this.btnComplete.TabIndex = 29;
            this.btnComplete.Text = "Complete";
            this.btnComplete.UseVisualStyleBackColor = true;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // rtxtPass
            // 
            this.rtxtPass.Location = new System.Drawing.Point(327, 147);
            this.rtxtPass.Name = "rtxtPass";
            this.rtxtPass.Size = new System.Drawing.Size(100, 83);
            this.rtxtPass.TabIndex = 31;
            this.rtxtPass.Text = "";
            this.rtxtPass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rtxtPass_KeyPress);
            // 
            // rtxtTack
            // 
            this.rtxtTack.Location = new System.Drawing.Point(327, 249);
            this.rtxtTack.Name = "rtxtTack";
            this.rtxtTack.Size = new System.Drawing.Size(100, 96);
            this.rtxtTack.TabIndex = 32;
            this.rtxtTack.Text = "";
            this.rtxtTack.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rtxtTack_KeyPress);
            // 
            // rtxtKick
            // 
            this.rtxtKick.Location = new System.Drawing.Point(327, 368);
            this.rtxtKick.Name = "rtxtKick";
            this.rtxtKick.Size = new System.Drawing.Size(100, 96);
            this.rtxtKick.TabIndex = 33;
            this.rtxtKick.Text = "";
            this.rtxtKick.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rtxtKick_KeyPress);
            // 
            // btnResult
            // 
            this.btnResult.Location = new System.Drawing.Point(272, 492);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(75, 23);
            this.btnResult.TabIndex = 41;
            this.btnResult.Text = "Show Result";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // PlayerProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 527);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.rtxtKick);
            this.Controls.Add(this.rtxtTack);
            this.Controls.Add(this.rtxtPass);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.txtSquadNo);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lstGoal);
            this.Controls.Add(this.lstGrubber);
            this.Controls.Add(this.lstPunt);
            this.Controls.Add(this.lstDrop);
            this.Controls.Add(this.lstScrabble);
            this.Controls.Add(this.lstSide);
            this.Controls.Add(this.lstRear);
            this.Controls.Add(this.lstFront);
            this.Controls.Add(this.lstPop);
            this.Controls.Add(this.lstSpin);
            this.Controls.Add(this.lstStandard);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Title);
            this.Name = "PlayerProfile";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckedListBox lstStandard;
        private System.Windows.Forms.CheckedListBox lstSpin;
        private System.Windows.Forms.CheckedListBox lstPop;
        private System.Windows.Forms.CheckedListBox lstSide;
        private System.Windows.Forms.CheckedListBox lstRear;
        private System.Windows.Forms.CheckedListBox lstFront;
        private System.Windows.Forms.CheckedListBox lstScrabble;
        private System.Windows.Forms.CheckedListBox lstGoal;
        private System.Windows.Forms.CheckedListBox lstGrubber;
        private System.Windows.Forms.CheckedListBox lstPunt;
        private System.Windows.Forms.CheckedListBox lstDrop;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtSquadNo;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.RichTextBox rtxtPass;
        private System.Windows.Forms.RichTextBox rtxtTack;
        private System.Windows.Forms.RichTextBox rtxtKick;
        private System.Windows.Forms.Button btnResult;
    }
}