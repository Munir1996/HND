﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class ShowPlayerProfile : Form
    {
        public ShowPlayerProfile()
        {
            //display the uers results
            InitializeComponent();
            showResult();
        }

        private void showResult()
        {
            rtxtPlayerPro.Text = "Your Name is " + Details.Name + "\n" +
                Details.Name + "'s Squad Number is " + Details.SquadNo + "\n" + "\n" +
                "Passing" + "\n" +
                "Standard = " + Details.StanderedLst + "\n" +
                "Spin = " + Details.SpinLst + "\n" +
                "Pop = " + Details.PopLst + "\n" + "\n" +
                "Tackling" + "\n" +
                "Front = " + Details.FrontLst + "\n" +
                "Rear = " + Details.RearLst + "\n" +
                "Side = " + Details.SideLst + "\n" +
                "Scrabble = " + Details.ScrabbleLst + "\n" + "\n" +
                "Kicking" + "\n" +
                "Drop = " + Details.DropLst + "\n" +
                "Punt = " + Details.PuntLst + "\n" +
                "Grubber = " + Details.GrubberLst + "\n" +
                "Goal = " + Details.GoalLst + "\n" + "\n" +
                "Passing Comments - " + Details.Passcomments + "\n" + "\n" +
                "Tackling Comments - " + Details.Tackcomments + "\n" + "\n" +
                "Kicking Comments - " + Details.Kickcomments;
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            //goes back to main window
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }
    }
}
