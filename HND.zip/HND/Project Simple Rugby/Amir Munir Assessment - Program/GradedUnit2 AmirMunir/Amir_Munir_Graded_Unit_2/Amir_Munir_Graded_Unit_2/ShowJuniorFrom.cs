﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class ShowJuniorFrom : Form
    {
        public ShowJuniorFrom()
        {
            //displays results from user
            InitializeComponent();
            showResults();
        }

        private void showResults()
        {
            rtxtResult.Text = "Your Name is " + Details.Name + "\n" +
                Details.Name + " Birthdays is " + Details.Dob + "\n" +
                Details.Name + " E-mail is " + Details.Email + "\n" +
                Details.Name + " SRU Number is " + Details.Sru + "\n" +
                Details.Name + " Telephone Number is " + Details.TeleNo + "\n" + "\n" +
                "The Guardian Name is " + Details.Gname + "\n" +
                Details.Gname + " E-mail is " + Details.Gemail + "\n" +
                Details.Gname + " Telephone Number is " + Details.GTeleNo;
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            //navigates to main window
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }
    }
}
