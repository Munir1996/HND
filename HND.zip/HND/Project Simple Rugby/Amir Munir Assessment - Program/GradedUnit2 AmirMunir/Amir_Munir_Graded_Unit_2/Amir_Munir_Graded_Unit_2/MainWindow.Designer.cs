﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegistrationMenu = new System.Windows.Forms.Button();
            this.btnRecordMenu = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnRegistrationMenu
            // 
            this.btnRegistrationMenu.Location = new System.Drawing.Point(48, 50);
            this.btnRegistrationMenu.Name = "btnRegistrationMenu";
            this.btnRegistrationMenu.Size = new System.Drawing.Size(111, 23);
            this.btnRegistrationMenu.TabIndex = 0;
            this.btnRegistrationMenu.Text = "Registration Menu";
            this.btnRegistrationMenu.UseVisualStyleBackColor = true;
            this.btnRegistrationMenu.Click += new System.EventHandler(this.btnRegistrationMenu_Click);
            // 
            // btnRecordMenu
            // 
            this.btnRecordMenu.Location = new System.Drawing.Point(48, 79);
            this.btnRecordMenu.Name = "btnRecordMenu";
            this.btnRecordMenu.Size = new System.Drawing.Size(111, 23);
            this.btnRecordMenu.TabIndex = 1;
            this.btnRecordMenu.Text = "Record Menu";
            this.btnRecordMenu.UseVisualStyleBackColor = true;
            this.btnRecordMenu.Click += new System.EventHandler(this.btnRecordMenu_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(48, 108);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(111, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select One Option";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(216, 162);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRecordMenu);
            this.Controls.Add(this.btnRegistrationMenu);
            this.Name = "MainWindow";
            this.Text = "MainWindow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegistrationMenu;
        private System.Windows.Forms.Button btnRecordMenu;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
    }
}