﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class RecordMenu : Form
    {
        public RecordMenu()
        {
            InitializeComponent();
        }

        //go back one page
        private void btnBack_Click(object sender, EventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }//end method

        //navigate to player profile
        private void btnPlayerProfile_Click(object sender, EventArgs e)
        {
            PlayerProfile pro = new PlayerProfile();
            pro.Show();
            this.Hide();
        }//end method
    }//end class
}//end namespace