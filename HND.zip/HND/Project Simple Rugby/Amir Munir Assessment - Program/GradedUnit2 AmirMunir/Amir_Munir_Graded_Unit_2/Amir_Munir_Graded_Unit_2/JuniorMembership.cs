﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class JuniorMembership : Form
    {
        public JuniorMembership()
        {
            InitializeComponent();
            //set a limt to the textbox
            txtTele.MaxLength = 11;
            txtSRU.MaxLength = 4;
            txtGTeleNum.MaxLength = 11;
        }

        //store the information provided by the user and validates it
        private void getJuniorDetails()
        {
            try
            {
                Details.Name = txtName.Text;
                Details.Dob = dtpDateOfBirth.Text;
                Details.Email = txtEmail.Text;
                Details.Sru = txtSRU.Text;
                Details.TeleNo = txtTele.Text;
            }//end try
            catch (Exception ex)
            {
                MessageBox.Show("All Fileds must be Complete");
            }//end catch

            //check for name
            if (Details.Name.Length <= 0)
            {
                MessageBox.Show("Must Enter Name");
            }

            //check for dob
            if (Details.Dob.Length <= 0)
            {
                MessageBox.Show("Must Choose Date of Birth");
            }

            //check for e-mail
            if (Details.Email.Length <= 0)
            {
                MessageBox.Show("Must Enter E-Mail");
            }
            else if (Details.Email.Contains("@") == false)
            {
                MessageBox.Show("Players E-mail Must Contain @");
            }

            //check sru number
            if (Details.Sru.Length <= 3)
            {
                MessageBox.Show("Must Enter a Four Digit SRU Number");
            }

            //check telephone number
            if (Details.TeleNo.Length <= 10)
            {
                MessageBox.Show("Must Enter an 11 digit for the Telephone Number ");
            }
        }//end method

        //gets gurdians details
        private void getGuardianDetails()
        {
            try
            {
                Details.Gname = txtGName.Text;
                Details.Gemail = txtGEmail.Text;
                Details.GTeleNo = txtGTeleNum.Text;
                
            }//end try
            catch (Exception ex)
            {
                MessageBox.Show("All fileds must be Complete");
            }//end catch

            //check name
            if (Details.Gname.Length <= 0)
            {
                MessageBox.Show("Must Enter Guardian's Name");
            }

            //check for e-mail
            if (Details.Gemail.Length <= 0)
            {
                MessageBox.Show("Must Enter Guardian's E-Mail");
            }
            else if (Details.Gemail.Contains("@") == false)
            {
                MessageBox.Show("Guardian's E-mail Must Have @");
            }

            //check telephone number
            if (Details.GTeleNo.Length <= 10)
            {
                MessageBox.Show("Must Enter 11 Digit for the Guardian’s Telephone Number");
            }
        }//end method

        //the user can only input numbers and use backspace
        private void txtSRU_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch !=8)
            {

                e.Handled = true;
            }
        }//end method     

        //enter only enter letters
        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if(!char.IsLetter(ch) && ch != 8 && ch !=32)
            {
                e.Handled = true;
            }
        }//end

        //enter only numbers and symbols
        private void txtDOB_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && !Char.IsPunctuation(ch))
            {
                e.Handled = true;
            }
        }//end

        //enter only numbers
        private void txtTele_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {

                e.Handled = true;
            }
        }//end

        //enter letters only and use space
        private void txtGName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }//end

        //enter only numbers
        private void txtGTeleNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {

                e.Handled = true;
            }
        }//end


        //naviagtes to show junior form
        private void btnResult_Click(object sender, EventArgs e)
        {
            ShowJuniorFrom result = new ShowJuniorFrom();
            result.Show();
            this.Hide();
        }//end button

        //stores user inputs
        private void btnComplete_Click(object sender, EventArgs e)
        {
            try
            {
                getJuniorDetails();
                getGuardianDetails();
            }
            catch (Exception ex)
            {
                MessageBox.Show("All Fileds must be Complete");
            }
        }//end button   
    }//end class
}//end namespace
