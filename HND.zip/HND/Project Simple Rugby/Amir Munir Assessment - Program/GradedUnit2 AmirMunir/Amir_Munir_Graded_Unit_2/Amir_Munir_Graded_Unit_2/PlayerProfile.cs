﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class PlayerProfile : Form
    {
        public PlayerProfile()
        {
            InitializeComponent();
            //set max amount of characters
            txtSquadNo.MaxLength = 2;
            rtxtKick.MaxLength = 75;
            rtxtTack.MaxLength = 75;
            rtxtPass.MaxLength = 75;
        }

        //
        private void getBasicInfo()
        {
            try
            {
                //stores the users name
                Details.Name = txtName.Text;
                //stores the user squad number
                Details.SquadNo = txtSquadNo.Text;
            }
            catch (Exception ex)
            {
                //fields must be filled
                MessageBox.Show("Must Complete Fields");
            }

            //optional feilds that can be filleds
            Details.Kickcomments = rtxtKick.Text;
            Details.Tackcomments = rtxtTack.Text;
            Details.Passcomments = rtxtPass.Text;
            
            if (txtName.Text.Length <= 0)
            {
                //must enter name in fields
                MessageBox.Show("Must Enter Name");
            }

            if (txtSquadNo.Text.Length <= 0)
            {
                //must enter squad number in fileds
                MessageBox.Show("Must Enter a Squad Number");
            }
        }

        //method for check list boxes
        private void checkList()
        {
            try
            {
                //stores the users score
                Details.StanderedLst = lstStandard.Text;
                Details.DropLst = lstDrop.Text;
                Details.FrontLst = lstFront.Text;
                Details.GoalLst = lstGoal.Text;
                Details.GrubberLst = lstGrubber.Text;
                Details.PopLst = lstPop.Text;
                Details.PuntLst = lstPunt.Text;
                Details.RearLst = lstRear.Text;
                Details.ScrabbleLst = lstScrabble.Text;
                Details.SideLst = lstSide.Text;
                Details.SpinLst = lstSpin.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Must Select Skill Level");
            }
        }

        //stores user information
        private void btnComplete_Click(object sender, EventArgs e)
        {
            getBasicInfo();
            //checkList();
        }

        //naviagets to show player profile
        private void btnResult_Click(object sender, EventArgs e)
        {
            ShowPlayerProfile profile = new ShowPlayerProfile();
            profile.Show();
            this.Hide();
        }

        //enter only letters
        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        //enter only numbers
        private void txtSquadNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {

                e.Handled = true;
            }
        }

        //enter only letters
        private void rtxtPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        //enter only letters
        private void rtxtTack_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        //enter only letters
        private void rtxtKick_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsLetter(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }
    }//end class
}//end namespce