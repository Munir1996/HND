﻿namespace Amir_Munir_Graded_Unit_2
{
    partial class ShowPlayerProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtPlayerPro = new System.Windows.Forms.RichTextBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtPlayerPro
            // 
            this.rtxtPlayerPro.Location = new System.Drawing.Point(12, 12);
            this.rtxtPlayerPro.Name = "rtxtPlayerPro";
            this.rtxtPlayerPro.Size = new System.Drawing.Size(260, 315);
            this.rtxtPlayerPro.TabIndex = 0;
            this.rtxtPlayerPro.Text = "";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(173, 353);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(99, 23);
            this.btnMainMenu.TabIndex = 1;
            this.btnMainMenu.Text = "Main Window";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // ShowPlayerProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 388);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.rtxtPlayerPro);
            this.Name = "ShowPlayerProfile";
            this.Text = "ShowPlayerProfile";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtPlayerPro;
        private System.Windows.Forms.Button btnMainMenu;
    }
}