﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amir_Munir_Graded_Unit_2
{
    public partial class ShowMembershipForm : Form
    {
        public ShowMembershipForm()
        {
            //displays the users information
            InitializeComponent();
            showResult();
        }

        private void showResult()
        {
            rtxtResult.Text = "Your Name is " + Details.Name + "\n" +
                Details.Name + " Birthdays is " + Details.Dob + "\n" +
                Details.Name + " E-mail is " + Details.Email + "\n" +
                Details.Name + " SRU Number is " + Details.Sru + "\n" +
                Details.Name + " Telephone Number is " + Details.TeleNo;
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            //naviagtes to the main window
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }
    }
}
